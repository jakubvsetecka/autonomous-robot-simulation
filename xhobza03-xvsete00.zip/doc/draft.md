# Conceptual Draft of the Project

1. Class Hierarchy

![Class Diagram](diagrams/class-diagram.svg)

2. Main Event Loop

![Main Event Loop](diagrams/seq-diagram.svg)